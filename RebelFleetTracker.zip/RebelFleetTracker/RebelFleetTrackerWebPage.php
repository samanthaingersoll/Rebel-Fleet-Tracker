<!DOCTYPE html>
<html>
<head>
<style>
.error {color:    #0f978a;}
body {
background-image: url("rebellogo.png");
background-color:   #ebcece;}
h1 {color: red;}    


div.container {
    width: 100%;
    border: 100% solid gray;
}

header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}

nav {
    float: left;
    max-width: 200px;
    margin: 0;
    padding: 1em;
}

nav ul {
    list-style-type: none;
    padding: 0;
}
   
nav ul a {
    text-decoration: none;
}

article {
    margin-left: 200px;
    border-left: 1px solid gray;
    padding: 1em;
    overflow: hidden;
}
</style>

</head>
<body>

<?php
$showall = "";
$homeplanet = "";
$basename = "";
$droidtype = "";
$weaponname = "";
$shipname = "";
$baseplanet = "";
$crewbase = "";
$nameErr1 = " ";
$nameErr2 = " ";
$nameErr3 = " ";
$nameErr4 = " ";
$nameErr5 = " ";
$nameErr6 = " ";
$nameErr7 = " ";
$nameErr8 = " ";
$nameErr9 = " ";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $showall = test_input ($_POST["showall"]);
  if (!preg_match("/^[a-zA-Z ]*$/",$showall)) {
    $nameErr1 = "Character not allowed:   Enter Table Name";
  }
  $homeplanet = test_input ($_POST["homeplanet"]);
  if (!preg_match("/^[a-zA-Z ]*$/",$homeplanet)) {
    $nameErr2= "Character not allowed:   Enter Planet Name";
  }
  $basename = test_input ($_POST["basename"]);
  if (!preg_match("/^[a-zA-Z ]*$/",$basename)) {
    $nameErr3= "Character not allowed:   Enter Base Planet";
  }
  $droidtype = test_input ($_POST["droidtype"]);
  if (!preg_match("/^[a-zA-Z 1-9 -]*$/",$droidtype)) {
    $nameErr4= "Character not allowed:   Enter Droid Type";
  }
  $weaponname = test_input ($_POST["weaponname"]);
  if (!preg_match("/^[a-zA-Z ]*$/",$weaponname)) {
    $nameErr5= "Character not allowed:   Enter Ship Name";
  }
  $shipname = test_input ($_POST["shipname"]);
  if (!preg_match("/^[a-zA-Z ]*$/",$shipname)) {
    $nameErr6= "Character not allowed:   Enter Ship Name";
  }
  $baseplanet = test_input ($_POST["baseplanet"]);
  if (!preg_match("/^[a-zA-Z ]*$/",$baseplanet)) {
    $nameErr7= "Character not allowed:   Enter Planet Name";
  }
  $crewbase = test_input ($_POST["crewbase"]);
  if (!preg_match("/^[a-zA-Z ]*$/",$crewbase)) {
    $nameErr8= "Character not allowed:   Enter Base Planet";
}
}
function test_input($data)
{
$data = trim($data);
$data = stripslashes($data);
$data = htmlspecialchars($data);
return $data;
}
?>


<div class="container">

<header>
   <h1>Search The Rebellion Fleet:</h1>
</header>

<nav>
  <ul>

<form method="post" action="RebelFleetTrackerWebPage.php">

  <br><br>
  Enter Table to Veiw All Entries:		
  <br><input type="text" name="showall">
  <span class="error">* <?php echo $nameErr1;?></span>
  <br><br>
  Pilot by Home Planet:		
  <br><input type="text" name="homeplanet">
  <span class="error">* <?php echo $nameErr2;?></span>
  <br><br>
  Ships at Rebel Base: 			
  <br><input type="text" name="basename">
  <span class="error">* <?php echo $nameErr3;?></span>
  <br><br>
  Droid Unit Number and Owner by Droid Type: 			
  <br><input type="text" name="droidtype">
  <span class="error">* <?php echo $nameErr4;?></span>
  <br><br>
  Weapons on Ship: 		
  <br><input type="text" name="weaponname">
  <span class="error">* <?php echo $nameErr5;?></span>
  <br><br>
  Pilot by Ship Name: 			
  <br><input type="text" name="shipname">
  <span class="error">* <?php echo $nameErr6;?></span>
  <br><br>
  Rebel Base by Planet: 	
  <br><input type="text" name="baseplanet">
  <span class="error">* <?php echo $nameErr7;?></span>
  <br><br>
  Crew by Base:			
  <br><input type="text" name="crewbase">
  <span class="error">* <?php echo $nameErr8;?></span>
  <br><br>
  <br><input type="submit">
</form>
  </ul>
</nav>

<?php
// Remember to replace 'username' and 'password'!
$conn = oci_connect('singerso', '1106Sammi', '(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(Host=db2.ndsu.edu)(Port=1521)))(CONNECT_DATA=(SID=cs)))');

//put your query here
$query = "";

if($showall !== ""){
	$query .= "SELECT * From ".$showall;
}

if($homeplanet !== ""){
	$query .= "SELECT fname, lname, race, bdate FROM Pilot WHERE LOWER(hPlanet) = LOWER('$homeplanet')";
}
if($basename !== ""){
	$query .= "SELECT name From Ship, RebelBase WHERE Ship.rbid = RebelBase.rbid AND LOWER(RebelBase.planet) =  LOWER('$basename')";
}
if($droidtype !== ""){
	$query .= "SELECT droid.did, fname, lname From Pilot, Droid WHERE Pilot.did = Droid.did AND LOWER(type) = LOWER('$droidtype')";
}
if($weaponname !== ""){
	$query .= "SELECT weapon.name FROM Ship, Weapon WHERE Ship.sid = Weapon.sid and LOWER(Ship.name) = LOWER('$weaponname')";
}
if($shipname !== ""){
	$query .= "SELECT fname, lname FROM Pilot, ship WHERE Ship.pid = pilot.pid AND LOWER(Ship.name) = LOWER('$shipname')";
}
if($baseplanet !== ""){
	$query .= "SELECT * FROM RebelBase WHERE LOWER(planet) = LOWER('$baseplanet')";
}
if($crewbase !== ""){
	$query .= "SELECT fname, lname, race, job FROM Crew, RebelBase WHERE Crew.rbid = RebelBase.rbid AND LOWER(RebelBase.planet) = LOWER('$crewbase')";
}
$stid = oci_parse($conn,$query);
oci_execute($stid,OCI_DEFAULT);
echo '<br/>';
echo "<strong>";
echo '<p style="color: Black; text-align: center">
      Results:
      </p>';
echo "</strong>";
echo '<br/>';
echo '<br/>';
//iterate through each row
$count = 0;
while ($row = oci_fetch_array($stid,OCI_ASSOC)) 
{
    //iterate through each item in the row and echo it  
    foreach ($row as $item => $val)    
    {
        echo '<p style=" text-align: center">'."<strong>".$item.': '."</strong>".$val.'</p>';
		$count = 1;
    }   
echo '<br/>';
}
if($count == 0){
	echo '<p style=" text-align: center">'.'No Results'.'</p>';
}
$count = 0;
oci_free_statement($stid);
oci_close($conn);


?>

</body>
</html>

