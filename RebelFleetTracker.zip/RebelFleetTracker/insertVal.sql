INSERT INTO Droid
VALUES (303030, 'C3PO Unit');
INSERT INTO Droid
VALUES (202020, 'Battle Droid Unit');
INSERT INTO Droid
VALUES (404040, 'Battle Droid Unit');
INSERT INTO Droid
VALUES (101010, 'R2-D2 Unit');

INSERT INTO License
VALUES (3000000,TO_DATE('2024-11-22', 'YYYY-MM-DD'),TO_DATE('1956-01-10', 'YYYY-MM-DD'));
INSERT INTO License
VALUES (2000000,TO_DATE('2023-12-07', 'YYYY-MM-DD'),TO_DATE('2002-05-11', 'YYYY-MM-DD'));
INSERT INTO License
VALUES (1000000,TO_DATE('2020-08-13', 'YYYY-MM-DD'),TO_DATE('2007-11-23', 'YYYY-MM-DD'));
INSERT INTO License
VALUES (4000000,TO_DATE('2021-03-23', 'YYYY-MM-DD'),TO_DATE('2007-11-23', 'YYYY-MM-DD'));
INSERT INTO License
VALUES (5000000,TO_DATE('2121-03-23', 'YYYY-MM-DD'),TO_DATE('2008-11-23', 'YYYY-MM-DD'));

INSERT INTO Pilot
VALUES (111111, 1000000, 101010, 'Luke', 'Skywalker', TO_DATE('1995-08-13', 'YYYY-MM-DD'),7, 'Human', 'Tatooine');
INSERT INTO Pilot
VALUES (222222, 2000000, 202020, 'Jar Jar', 'Binks', TO_DATE('1983-12-07', 'YYYY-MM-DD'),3, 'Gungan', 'Naboo');
INSERT INTO Pilot
VALUES (333333, 3000000, 303030, 'Chewbacca', 'Tojj', TO_DATE('1944-11-22', 'YYYY-MM-DD'),7, 'Wookiee', 'Kashyyyk');
INSERT INTO Pilot
VALUES (444444, 4000000, 303030, 'Han', 'Solo', TO_DATE('1944-11-22', 'YYYY-MM-DD'),7, 'Human', 'Corellia');
INSERT INTO Pilot
VALUES (555555, 4000000, 101010, 'Leia', 'Organa', TO_DATE('1944-11-22', 'YYYY-MM-DD'),7, 'Human', 'Alderaan');
INSERT INTO Pilot
VALUES (666666, 2000000, 303030, 'Obi-Wan', 'Kenobi', TO_DATE('1944-11-22', 'YYYY-MM-DD'),7, 'Human', 'Tatooine');
INSERT INTO Pilot
VALUES (777777, 4000000, 404040, 'Kal', 'Drogo', TO_DATE('1944-11-22', 'YYYY-MM-DD'),7, 'Hutt', 'Corellia');

INSERT INTO RebelBase
VALUES (1, 'Hoth', 500, 0);
INSERT INTO RebelBase
VALUES (2, 'Yavin 4', 200, 1000);
INSERT INTO RebelBase
VALUES (3, 'Crait', 1000, 7000);
INSERT INTO RebelBase
VALUES (4, 'Dantooine', 800, 5000);
INSERT INTO RebelBase
VALUES (5, '5251977', 300, 8000);

INSERT INTO Weapon
VALUES (1,1,10, 'Blaster');
INSERT INTO Weapon
VALUES (8,2,10, 'Blaster');
INSERT INTO Weapon
VALUES (7,5,10, 'Blaster');
INSERT INTO Weapon
VALUES (2, 5, 'Light Saber');
INSERT INTO Weapon
VALUES (3,1, 10, 'Bowcaster');
INSERT INTO Weapon
VALUES (4,3, 5, 'Thermal Detanator');
INSERT INTO Weapon
VALUES (6,4,500, 'Turret');
INSERT INTO Weapon
VALUES (9,4,10, 'Blaster');
INSERT INTO Weapon
VALUES (10,1,10, 'Blaster');

INSERT INTO Crew
VALUES (1, 1, 'Samantha', 'Ingersoll', TO_DATE('1876-11-07', 'YYYY-MM-DD'), 'Human', 'Tatooine', 'Engineer');
INSERT INTO Crew
VALUES (2, 4, 'Tim', 'Hunter',  TO_DATE('1942-10-11', 'YYYY-MM-DD'), 'Jawa', 'Bespin', 'Gunner');
INSERT INTO Crew
VALUES (3, 2, 'Michael', 'Holthaus', TO_DATE('1964-12-11', 'YYYY-MM-DD'), 'Kamarian', 'Naboo', 'Gunner');
INSERT INTO Crew
VALUES (4, 3, 'Jacob', 'Bman', TO_DATE('1984-02-24', 'YYYY-MM-DD'), 'Hutt', 'Naboo', 'Engineer');
INSERT INTO Crew
VALUES (5, 1, 'Carrie', 'Smith', TO_DATE('1984-02-24', 'YYYY-MM-DD'), 'Hutt', 'Dagobah', 'Engineer');
INSERT INTO Crew
VALUES (6, 2, 'Brenden', 'Cass', TO_DATE('1884-04-20', 'YYYY-MM-DD'), 'Hssiss', 'Dagobah', 'Gunner');
INSERT INTO Crew
VALUES (7, 5, 'Benjamin', 'Ingersoll', TO_DATE('1879-10-02', 'YYYY-MM-DD'), 'Human', 'Tatooine', 'Gunner');
INSERT INTO Crew
VALUES (8, 3, 'Sloane', 'Smith', TO_DATE('1886-11-07', 'YYYY-MM-DD'), 'Hssiss', 'Tatooine', 'Scientist');
INSERT INTO Crew
VALUES (9, 1, 'Eli', 'Gerdigin', TO_DATE('1936-11-07', 'YYYY-MM-DD'), 'Jawa', 'Naboo', 'Medic');
INSERT INTO Crew
VALUES (10, 2, 'Alexis', 'Sarri', TO_DATE('1836-11-07', 'YYYY-MM-DD'), 'Kamartian', 'Bespin', 'Medic');
INSERT INTO Crew
VALUES (11, 3, 'Kristy', 'Brandt', TO_DATE('1833-11-07', 'YYYY-MM-DD'), 'Hutt', 'Tatooine', 'Medic');
INSERT INTO Crew
VALUES (12, 4, 'Jacob', 'Huesman', TO_DATE('1831-11-07', 'YYYY-MM-DD'), 'Human', 'Tatooine', 'Medic');
INSERT INTO Crew
VALUES (13, 5, 'Konnor', 'Bird', TO_DATE('1830-11-07', 'YYYY-MM-DD'), 'Human', 'Bespin', 'Medic');
INSERT INTO Crew
VALUES (14, 1, 'Levi', 'Girtz', TO_DATE('1836-12-07', 'YYYY-MM-DD'), 'Hssiss', 'Dagobah', 'Medic');


INSERT INTO Ship
VALUES (1, 333333, 1, 'Millennium Falcon', 'Freighter', 2, 10, 3000);
INSERT INTO Ship
VALUES (2, 111111, 2, 'xWing', 'Starfighter', 1, 1, 1000);
INSERT INTO Ship
VALUES (3, 222222, 3, 'Mon Calamari', 'Battle Cruiser', 5, 400, 4000);
INSERT INTO Ship
VALUES (4, 333333, 2, 'Tantive IV', 'Cr90 Corvette', 3, 150, 3000);
INSERT INTO Ship
VALUES (5, 777777, 2, 'xWing', 'Starfighter', 1, 1, 1000);





