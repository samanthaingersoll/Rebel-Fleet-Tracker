drop table Droid casade constraints;
drop table Pilot cascade constraints;
drop table License cascade constraints;
drop table Weapon cascade constraints;
drop table Ship cascade constraints;
drop table Crew cascade constraints;
drop table RebelBase cascade constraints;
